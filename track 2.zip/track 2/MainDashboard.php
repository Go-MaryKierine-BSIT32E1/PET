<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            display: flex;
            flex-direction: row;
            background-color: white;
            margin: 0;
            /* Remove default margin */
            padding: 0;
            /* Remove default padding */
        }

        #sidebar {
            width: 20%;
            /* Adjust width as needed */
            height: 100vh;
            /* Full height */
            background-color: white;
            /* Sidebar background color */
        }

        #content {
            flex-grow: 1;
            /* Take remaining space */
            height: 100vh;
            /* Full height */
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        #logo {
            max-width: 100%;
            /* Ensure image does not exceed container width */
            max-height: 100%;
            /* Ensure image does not exceed container height */
            width: auto;
            /* Allow image to adjust width automatically */
            height: auto;
            /* Allow image to adjust height automatically */
            object-fit: contain;
            /* Maintain aspect ratio */
            position: fixed;
            /* Fixed position relative to viewport */
            top: 10px;
            /* Adjust top position as needed */
            left: 500px;
            /* Adjust left position as needed */
        }

        @media (max-width: 700px) {

            span {
                display: none;
            }

            #sidebar {
                width: 10%;
                /* Adjust width as needed */
                height: 100vh;
                /* Full height */
                background-color: white;
                /* Sidebar background color */
            }

            #content {
                height: 20vh;
                /* Full height */
                padding: 2px;
                display: flex;
                align-items: start;
                justify-content: start;
            }

            #logo {
                max-width: 50%;
                max-height: 50%;
                width: auto;
                height: auto;
                object-fit: contain;
                position: fixed;
                top: 30%;
                left: 30%;
            }
        }
    </style>
    <title>Main Dashboard</title>
</head>

<body>


    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 size-full">
            <div id="content">
                <img id="logo" src="./images/logo.png" alt="Logo">
                    <?php include('./BarGraph.php') ?>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="./javascript/sessionmessage.js"></script>
    <script src="./javascript/active.js"></script>

</body>

</html>