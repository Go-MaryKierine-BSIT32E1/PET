<?php
session_start();

// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Replace with your MySQL password if set
$dbname = "user_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize or get existing registered pets array from session
$registeredPets = isset($_SESSION["registeredPets"]) ? $_SESSION["registeredPets"] : [];

// Process registration form and delete request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if delete request
    if (isset($_POST["deleteIndex"]) && is_numeric($_POST["deleteIndex"])) {
        $deleteIndex = $_POST["deleteIndex"];
        // Check if index exists in session array
        if (isset($registeredPets[$deleteIndex])) {
            // Get pet details
            $petToDelete = $registeredPets[$deleteIndex];
            $petName = $petToDelete['petName'];
            $petAge = $petToDelete['petAge'];
            $ownerName = $petToDelete['ownerName'];

            // Delete pet from database based on pet details
            $stmt = $conn->prepare("DELETE FROM pets WHERE petName = ? AND petAge = ? AND ownerName = ?");
            $stmt->bind_param("sis", $petName, $petAge, $ownerName);
            if ($stmt->execute()) {
                // Remove pet from session array
                unset($registeredPets[$deleteIndex]);
                // Reset array keys
                $registeredPets = array_values($registeredPets);
                // Save updated registered pets array back to session
                $_SESSION["registeredPets"] = $registeredPets;
                // Redirect to refresh page after deletion
                header("Location: " . $_SERVER["PHP_SELF"]);
                exit();
            } else {
                echo "Error deleting pet: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        // Add new pet to registered pets array
        $newPet = [
            "petName" => $_POST["petName"],
            "petAge" => $_POST["petAge"],
            "ownerName" => $_POST["ownerName"]
        ];
        
        // Insert new pet into the database
        $petName = $_POST["petName"];
        $petAge = $_POST["petAge"];
        $ownerName = $_POST["ownerName"];

        $stmt = $conn->prepare("INSERT INTO pets (petName, petAge, ownerName) VALUES (?, ?, ?)");
        $stmt->bind_param("sis", $petName, $petAge, $ownerName);

        if ($stmt->execute()) {
            // Add new pet to session array
            $newPet['id'] = null; // Adjust as per your application logic
            $registeredPets[] = $newPet;

            // Save updated registered pets array back to session
            $_SESSION["registeredPets"] = $registeredPets;

            // Redirect to same page to refresh the list after successful insertion
            header("Location: " . $_SERVER["PHP_SELF"]);
            exit();
        } else {
            echo "Error inserting new pet: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Our Pets</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0px;
            background-color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ccc;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            font-size: 16px;
        }

        th {
            background-color: #f2f2f2;
        }

        form {
            display: inline; /* Keep forms inline for delete buttons */
        }

        .delete-btn {
            background-color: red;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            font-size: 14px;
        }

        h1,
        h2 {
            text-align: center;
        }

        .form {
            display: flex;
            flex-direction: column;
            align-items: center; /* Center align items horizontally */
            max-width: 400px; /* Example of setting a maximum width for the form */
            margin: 0 auto; /* Center align form horizontally */
            padding: 20px;
            background-color: #f2f2f2; /* Light gray background for form */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Shadow for form */
        }

        label,
        input {
            margin-bottom: 10px;
            padding: 12px;
            border-radius: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"] {
            padding: 15px 30px;
            background-color: #082D0F;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #17b890;
        }

        .pets-container {
            text-align: center;
            margin: 0 auto;
            max-width: 800px;
        }

        p {
            font-size: 16px;
        }

        .Back,
        .map {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            text-decoration: none;
            color: #ffffff;
            background-color: #082D0F;
            border: 1px solid green;
            border-radius: 5px;
            transition: background-color 0.3s, border-color 0.3s, color 0.3s;
        }

        .Back:hover,
        .map:hover {
            background-color: #17b890;
            border-color: darkgreen;
        }

        .Back:active,
        .map:active {
            background-color:  #082D0F;
            border-color: #004fa2;
        }

        #sidebar {
            width: 20%; /* Adjust width as needed */
            height: 100vh; /* Full height */
            background-color: white; /* Sidebar background color */
        }

        @media only screen and (max-width: 768) {
            .container {
                max-width: 100%; /* Adjust form width to full width on smaller screens */
                background-color: red !important;
            }
        }


        @media (max-width: 700px) {
            
            span {
                display: none;
            }

            #sidebar {
                width: 10%;
                /* Adjust width as needed */
                height: 100vh;
                /* Full height */
                background-color: white;
                /* Sidebar background color */
            }
        }

    </style>
</head>
<body>


    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 size-full">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 m-10 md:mt-48">
                <div class="container">
                    <h1>Pet Registration</h1>
                    <!-- Registration Form -->
                    <form class="form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                        <label for="petName">Pet Name:</label>
                        <input type="text" id="petName" name="petName" required>

                        <label for="petAge">Pet Age:</label>
                        <input type="number" id="petAge" name="petAge" required>

                        <label for="ownerName">Owner Name:</label>
                        <input type="text" id="ownerName" name="ownerName" required>

                        <input type="submit" value="Register Pet">
                    </form>
                </div>
                <div class="container">
                    <h2>Our Pets</h2>
                    <?php if (count($registeredPets) > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Pet Name</th>
                                    <th>Pet Age</th>
                                    <th>Owner Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($registeredPets as $index => $pet): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($pet["petName"]); ?></td>
                                        <td><?php echo htmlspecialchars($pet["petAge"]); ?></td>
                                        <td><?php echo htmlspecialchars($pet["ownerName"]); ?></td>
                                        <td>
                                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                                                <input type="hidden" name="deleteIndex" value="<?php echo $index; ?>">
                                                <input type="submit" class="delete-btn" value="Delete">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No pets registered yet.</p>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>

</body>
</html>