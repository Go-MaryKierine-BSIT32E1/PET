<!DOCTYPE html>
<html lang="en">

<head>
    <title>Simple Notes</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
        /* Global Styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to bottom, #e0f7fa, #b2ebf2); /* Light blue gradient background */
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            position: relative;
            z-index: 1;
        }

        .content {
            margin-bottom: 30px;
            padding: 20px;
            border-radius: 8px;
            background-color: #f8f9fa; /* Gray background for content sections */
        }

        .form-control {
            border: 1px solid #ced4da;
            border-radius: 8px;
            padding: 10px;
            font-size: 18px;
            background-color: #ffffff;
            width: 100%;
            box-sizing: border-box;
        }

        .btn-primary, .btn-edit, .btn-delete {
            border: none;
            padding: 10px 25px;
            font-size: 1em;
            border-radius: 8px;
            color: #ffffff;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        .btn-primary {
            background-color: #17b890;
        }

        .btn-edit {
            background-color: #17b890;
        }

        .btn-delete {
            background-color: #dc3545;
        }

        .btn-primary:hover, .btn-edit:hover, .btn-delete:hover {
            background-color: #0d7063;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .btn-primary:active, .btn-edit:active, .btn-delete:active {
            background-color: #0a5a4f;
        }

        .note-item {
            background-color: #ffffff; /* White background for individual notes */
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            position: relative;
            box-sizing: border-box;
            border: 1px solid #d1bfa7; /* Light brown border */
            display: flex;
            flex-direction: column;
            background: linear-gradient(to bottom, #fef6e4, #d1bfa7); /* Gradient background */
        }

        .note-content {
            font-size: 1em;
            color: #495057;
            background-color: #f8f9fa; /* Light gray background for note content */
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 50px; /* Ensure space for buttons */
        }

        .note-actions {
            position: absolute;
            bottom: 15px;
            right: 15px;
            display: flex;
            gap: 10px; /* Space between buttons */
        }

        .note-actions button {
            margin-top: 10px; /* Space above buttons */
            font-size: 0.9em; /* Adjust font size for better fit */
            min-width: 80px; /* Ensure all buttons have a minimum width */
        }

        #notes {
            background-color: #f8f9fa; /* Light gray background */
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px; /* Space from separator line */
            display: none; /* Hidden initially */
        }

        #notes.has-notes {
            display: block; /* Show when notes are added */
        }
    </style>
</head>

<body>

    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 h-full">
            <div class="container">
                <!-- Take a Note Section -->
                <div class="content">
                    <textarea id="addTxt" class="form-control" rows="4" placeholder="Type your note here..."></textarea>
                    <div class="text-right mt-4">
                        <button id="addBtn" class="btn-primary">Add</button>
                    </div>
                </div>

                <!-- Separator -->
                <hr class="separator">

                <!-- Notes List Section -->
                <div class="content">
                    <div id="notes">
                        <!-- Sample note items will be dynamically inserted here -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!----------JAVASCRIPT--------->
    <script src="./note/js/jquery.min.js"></script>
    <script src="./note/js/popper.min.js"></script>
    <script src="./note/js/bootstrap.min.js"></script>
    <script src="./note/js/app.js"></script>
    <script>
        document.getElementById('addBtn').addEventListener('click', function() {
            var noteContent = document.getElementById('addTxt').value;
            if (noteContent.trim()) {
                var noteList = document.getElementById('notes');
                var noteItem = document.createElement('div');
                noteItem.className = 'note-item';
                noteItem.innerHTML = `<div class='note-content' contenteditable="false">${noteContent}</div>
                                      <div class='note-actions'>
                                          <button class='btn-edit'>Edit</button>
                                          <button class='btn-delete'>Delete</button>
                                      </div>`;
                noteList.appendChild(noteItem);
                document.getElementById('addTxt').value = '';
                attachEventListeners(); // Ensure event listeners are attached to new elements
                updateNotesListBackground(); // Update background when a note is added
            }
        });

        function attachEventListeners() {
            document.querySelectorAll('.btn-edit').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var noteContent = this.closest('.note-item').querySelector('.note-content');
                    if (noteContent.isContentEditable) {
                        noteContent.contentEditable = "false";
                        this.textContent = "Edit";
                    } else {
                        noteContent.contentEditable = "true";
                        noteContent.focus();
                        this.textContent = "Save";
                    }
                });
            });

            document.querySelectorAll('.btn-delete').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    this.closest('.note-item').remove();
                    updateNotesListBackground(); // Update background when a note is deleted
                });
            });
        }

        function updateNotesListBackground() {
            var notesContainer = document.getElementById('notes');
            if (notesContainer.children.length > 0) {
                notesContainer.classList.add('has-notes');
            } else {
                notesContainer.classList.remove('has-notes');
            }
        }

        // Initialize event listeners on page load
        attachEventListeners();
        updateNotesListBackground();
    </script>

</body>

</html>
