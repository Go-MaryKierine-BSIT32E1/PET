<?php
include 'config.php'; // Ensure this file contains your database connection details

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    // Check if the email exists
    $query = mysqli_query($conn, "SELECT * FROM `user_form` WHERE email = '$email'") or die('query failed: ' . mysqli_error($conn));
    if (mysqli_num_rows($query) > 0) {
        $token = bin2hex(random_bytes(50)); // Generate a token
        $expires = date("U") + 3600; // Token expires in 1 hour
        
        // Store the token and expiration in the database
        $update = mysqli_query($conn, "UPDATE `user_form` SET reset_token = '$token', token_expires = '$expires' WHERE email = '$email'") or die('query failed: ' . mysqli_error($conn));
        
        // Send the email
        $to = $email;
        $subject = 'Password Reset Request';
        $message = 'To reset your password, please click the link below:\n';
        $message .= 'http://yourwebsite.com/reset_password.php?token=' . $token;
        $headers = 'From: no-reply@yourwebsite.com';
        
        if (mail($to, $subject, $message, $headers)) {
            echo 'An email with a password reset link has been sent to ' . $email;
        } else {
            echo 'Failed to send email.';
        }
    } else {
        echo 'No account found with that email address.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
</head>
<body>
    <form action="" method="post">
        <h2>Forgot Password</h2>
        <input type="email" name="email" placeholder="Enter your email" required>
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>
