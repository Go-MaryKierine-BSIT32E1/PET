<?php
include 'config.php';

$message = []; // Initialize an array to store messages

if (isset($_POST['submit'])) {
    // Escape user inputs for security
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);

    // Validate if email already exists
    $query = "SELECT * FROM `user_form` WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $message[] = 'User already exists with this email address';
    } else {
        // Validate passwords match
        if ($password != $cpassword) {
            $message[] = 'Confirm password does not match!';
        } else {
            // Hash the password (using md5 is not recommended for real applications)
            $hashed_password = md5($password);

            // Insert new user into database
            $insert_query = "INSERT INTO `user_form` (name, email, password) VALUES ('$name', '$email', '$hashed_password')";
            $insert_result = mysqli_query($conn, $insert_query);

            if ($insert_result) {
                $message[] = 'Registered successfully!';
                header('location: login.php');
                exit();
            } else {
                $message[] = 'Registration failed: ' . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;600&display=swap">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Oswald', sans-serif;
            background: linear-gradient(135deg, #96b9d0, #a4c3d2);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #333;
        }

        .form-container {
            max-width: 500px;
            width: 100%; /* Ensure it adapts to screen width */
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border: 1px solid #ddd;
            box-sizing: border-box; /* Include padding and border in the element's total width and height */
            margin: 0 auto; /* Center the form container */
        }

        h3 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
            font-weight: 600;
        }

        .box {
            width: 100%; /* Full width */
            padding: 12px 16px; /* Adjusted padding */
            margin: 10px 0; /* Consistent margin */
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            background-color: #f9f9f9;
            color: #333;
            box-sizing: border-box; /* Ensure padding is included in width */
        }

        .box:focus {
            border-color: #17b890;
            outline: none;
            box-shadow: 0 0 5px rgba(23, 184, 144, 0.5);
        }

        .btn {
            width: 100%; /* Match the input boxes */
            padding: 15px;
            margin: 20px 0; /* Consistent margin */
            background-color: #17b890;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #139c75;
        }

        .message {
            background-color: #ff6b6b;
            color: #fff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: center;
            border: 1px solid #e74c3c;
        }

        .test {
            font-size: 16px;
            color: #666;
            margin-top: 10px;
            text-align: center;
        }

        .test a {
            color: #17b890;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .test a:hover {
            color: #128a6c;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .form-container {
                flex-direction: column;
            }

            .form-container form {
                width: 100%;
            }

            .btn {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
<div class="form-container">
    <form action="" method="post">
        <h3>Register Now</h3>
        <?php
        if (!empty($message)) {
            foreach ($message as $msg) {
                echo '<div class="message">' . $msg . '</div>';
            }
        }
        ?>
        <input type="text" name="name" placeholder="Enter Username..." class="box" required>
        <input type="email" name="email" placeholder="Enter Email..." class="box" required>
        <input type="password" name="password" placeholder="Enter Password..." class="box" required>
        <input type="password" name="cpassword" placeholder="Confirm Password..." class="box" required>
        <input type="submit" name="submit" value="Register" class="btn">
        <p class="test">Already have an account? <a href="login.php">Login</a></p>
    </form>
</div>
</body>
</html>
