<?php
session_start();
include 'config.php';

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = mysqli_real_escape_string($conn, md5($_POST['password']));

    $select = mysqli_query($conn, "SELECT * FROM `user_form` WHERE email = '$email' AND password = '$pass'") or die('Query failed: ' . mysqli_error($conn));

    if (mysqli_num_rows($select) > 0) {
        $row = mysqli_fetch_assoc($select);
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['user_name'] = $row['name'];
        header('Location: ../MainDashboard.php');
        exit;
    } else {
        $message[] = 'Invalid email or password!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login | Pet Tracker</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
   <style>
      body {
         display: flex;
         justify-content: center;
         align-items: center;
         min-height: 100vh;
         margin: 0;
         font-family: 'Poppins', sans-serif;
         background: linear-gradient(135deg, #96b9d0, #a4c3d2);
         color: #333;
      }

      .form-container {
         display: flex;
         width: 90%;
         max-width: 900px;
         background: #fff;
         border-radius: 10px;
         box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
         overflow: hidden;
         flex-direction: row;
         border: 1px solid #ddd;
         padding: 0;
         margin: 20px;
      }

      .image-section,
      .form-section {
         flex: 1;
         display: flex;
         justify-content: center;
         align-items: center;
         padding: 40px;
      }

      .image-section {
         background: linear-gradient(135deg, #9dc5bb, #dee5e5);
         color: #fff;
         text-align: center;
         flex-direction: column;
      }

      .image-section h1 {
         font-size: 34px;
         font-weight: 700;
         margin-bottom: 20px;
         line-height: 1.2;
      }

      .image-section p {
         font-size: 18px;
         line-height: 1.6;
         margin-bottom: 20px;
         max-width: 80%;
         margin-left: auto;
         margin-right: auto;
      }

      .image-section img {
         width: 100%;
         max-width: 300px;
         height: auto;
         margin-top: 20px;
         filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));
      }

      .form-section {
         background: #f9f9f9;
         color: #333;
         flex-direction: column;
         justify-content: center;
         text-align: center;
         padding: 40px;
      }

      .form-section h3 {
         font-size: 30px;
         font-weight: 700;
         margin-bottom: 20px;
         text-align: center;
      }

      .form-section .box {
         border: 1px solid #ddd;
         border-radius: 5px;
         padding: 12px 16px;
         margin-bottom: 15px;
         font-size: 16px;
         color: #555;
         background-color: #fff;
         box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
         width: 100%;
         max-width: 400px;
         box-sizing: border-box;
         margin-left: auto;
         margin-right: auto;
         text-align: left;
      }

      .form-section .box:focus {
         border-color: #17b890;
         outline: none;
         box-shadow: 0 0 5px rgba(23, 184, 144, 0.5);
      }

      .form-section .btn {
         background: #17b890;
         color: #fff;
         border: none;
         border-radius: 5px;
         padding: 15px;
         cursor: pointer;
         font-size: 18px;
         margin-bottom: 20px;
         transition: background 0.3s ease, transform 0.2s;
         box-shadow: 0 4px 10px rgba(23, 184, 144, 0.2);
         width: 100%;
         max-width: 400px;
         margin-left: auto;
         margin-right: auto;
      }

      .form-section .btn:hover {
         background: #128a6c;
         transform: translateY(-2px);
         box-shadow: 0 6px 15px rgba(23, 184, 144, 0.3);
      }

      .form-section .btn:active {
         transform: translateY(0);
         box-shadow: 0 4px 10px rgba(23, 184, 144, 0.2);
      }

      .form-section p {
         font-size: 16px;
         color: #666;
         margin-top: 10px;
         text-align: center;
      }

      .form-section p a {
         color: #17b890;
         text-decoration: none;
         font-weight: 500;
         transition: color 0.3s;
      }

      .form-section p a:hover {
         color: #128a6c;
         text-decoration: underline;
      }

      @media (max-width: 768px) {
         .form-container {
            flex-direction: column;
         }

         .image-section,
         .form-section {
            width: 100%;
            padding: 20px;
         }

         .image-section {
            justify-content: center;
            text-align: center;
         }

         .image-section img {
            width: 100%;
            max-width: 250px;
         }
      }
   </style>
</head>
<body>
   
<div class="form-container">
   <div class="image-section">
      <h1>Welcome!</h1>
      <p>Let’s ensure your pet’s happiness together. Create a better world for our fur babies.</p>
   </div>
   <div class="form-section">
      <?php
      if (isset($message)) {
         foreach ($message as $msg) {
            echo '<div class="message">'.$msg.'</div>';
         }
      }
      ?>
      <form action="" method="post">
         <input type="email" name="email" placeholder="Email..." class="box" required>
         <input type="password" name="password" placeholder="Password..." class="box" required>
         <input type="submit" name="submit" value="Log In" class="btn">
         <p>New to PetTracker? <a href="register.php">Create an Account</a></p>
      </form>
   </div>
</div>

</body>
</html>
