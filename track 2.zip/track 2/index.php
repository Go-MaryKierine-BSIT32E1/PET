<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;600&display=swap" rel="stylesheet">
    <title>Login</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            font-family: 'Oswald', sans-serif;
            background: url('./images/bg.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6); /* Add a semi-transparent overlay */
        }

        .header {
            font-size: 6vw; /* Responsive font size */
            color: white;
            text-align: center;
            margin-bottom: 20px; /* Adjusted for better spacing */
            font-weight: 600;
            text-shadow: 3px 3px 6px rgba(0,0,0,0.5); /* Enhanced text shadow */
        }

        .login, .signup {
            display: inline-block;
            background-color: #007BFF; /* Primary color for buttons */
            color: white;
            margin: 10px;
            border-radius: 50px; /* Rounded corners for modern look */
            padding: 15px 40px; /* Adjusted padding */
            font-size: 18px;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.3s ease; /* Smooth transition */
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2); /* Button shadow */
        }

        .login:hover, .signup:hover {
            background-color: #0056b3; /* Darken on hover */
            transform: translateY(-2px); /* Slight lift on hover */
        }

        @media (max-width: 768px) {
            .header {
                font-size: 8vw; /* Adjust font size for smaller screens */
            }

            .login, .signup {
                font-size: 16px;
                padding: 12px 30px; /* Adjust padding for smaller screens */
            }
        }

    </style>
</head>
<body>
    <div class="container">
        <h1 class="header">PetTracker</h1>
        <a href="./user/login.php" class="login">Log In</a>
        <a href="./user/register.php" class="signup">Sign Up</a>
    </div>
    <script src="./javascript/sessionmessage.js"></script>
</body>
</html>
