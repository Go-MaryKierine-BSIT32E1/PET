<?php
session_start();

date_default_timezone_set('Asia/Manila');


// Database connection parameters
$servername = "localhost"; // Replace with your server name if different
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "user_db"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure UTF-8 encoding
$conn->set_charset("utf8mb4");

// Check if POST request to add marker to history
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    $name = $_POST['name'];
    $timestamp = $_POST['timestamp'];

    // Geocoding to get the exact location address (using OpenCage API)
    $apiKey = 'efb3bdb1602f47daa33b17492c45defe'; // Replace with your geocoding API key
    $url = "https://api.opencagedata.com/geocode/v1/json?q=$lat+$lng&key=$apiKey";
    $response = file_get_contents($url);
    $data = json_decode($response, true);
    $address = isset($data['results'][0]['formatted']) ? $data['results'][0]['formatted'] : 'Address not found';

    // Format timestamp to Philippine standard time (PST) and international standard date
    $timestamp = date('Y-m-d H:i:s', strtotime($timestamp)); // Convert timestamp to PHP DateTime format

    // SQL to insert marker data into history table
    $sql = "INSERT INTO history (lat, lng, name, address, timestamp) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ddsss", $lat, $lng, $name, $address, $timestamp);
    $stmt->execute();
    $stmt->close();

    // Store in session history (optional)
    if (!isset($_SESSION['history'])) {
        $_SESSION['history'] = [];
    }

    // Fetch the last inserted ID to use in session data
    $last_id = $conn->insert_id;

    $_SESSION['history'][] = [
        'id' => $last_id,
        'lat' => $lat,
        'lng' => $lng,
        'name' => $name,
        'address' => $address,
        'timestamp' => $timestamp
    ];

    echo 'History saved.';
    // Redirect to avoid re-posting on page refresh
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Check if GET request to clear history
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['clear']) && $_GET['clear'] == true) {
    // SQL to truncate (clear) history table
    $sql_clear = "TRUNCATE TABLE history";
    if ($conn->query($sql_clear) === TRUE) {
        echo 'History cleared.';
        $_SESSION['history'] = []; // Clear session history
    } else {
        echo 'Error clearing history: ' . $conn->error;
    }
    // Redirect to avoid re-clearing on page refresh
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Check if GET request to delete a specific history item
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $deleteId = $_GET['delete'];
    // SQL to delete specific record from history table
    $sql_delete = "DELETE FROM history WHERE id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $deleteId);
    if ($stmt_delete->execute()) {
        // Remove the item from session history as well
        foreach ($_SESSION['history'] as $index => $marker) {
            if ($marker['id'] == $deleteId) {
                unset($_SESSION['history'][$index]);
                // Reindex the array after deletion
                $_SESSION['history'] = array_values($_SESSION['history']);
                break;
            }
        }
        echo 'History item deleted.';
    } else {
        echo 'Error deleting history item: ' . $conn->error;
    }
    $stmt_delete->close();
    // Redirect to avoid re-deleting on page refresh
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Marker History</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 50px;
        }

        table,
        th,
        td {
            border: 1px solid #ccc;
        }

        th,
        td {
            padding: 40px;
            text-align: left;
            font-size: 20px;
        }

        th {
            background-color: #f2f2f2;
        }

        .clear-btn {
            display: inline-block;
            padding: 20px 20px;
            background-color: #082D0F;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .clear-btn:hover {
            background-color: #17B890;
        }

        h1 {
            text-align: center;
        }

        #sidebar {
            width: 20%;
            /* Adjust width as needed */
            height: 100vh;
            /* Full height */
            background-color: white;
            /* Sidebar background color */
        }

        /* CSS for the dash button */
        .dash {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            text-decoration: none;
            color: white;
            background-color: #082D0F;
            border: 1px solid green;
            border-radius: 5px;
            transition: background-color 0.3s, border-color 0.3s, color 0.3s;
        }

        .dash:hover {
            background-color: #17B890;
            border-color: green;
        }

        .dash:active {
            background-color: #004fa2;
            border-color: #004fa2;
        }

        @media (max-width: 700px) {
            
            span {
                display: none;
            }

            #sidebar {
                width: 10%;
                /* Adjust width as needed */
                height: 100vh;
                /* Full height */
                background-color: white;
                /* Sidebar background color */
            }
        }
    </style>
</head>

<body>
    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 size-full">
            <div class="flex flex-col m-10">


                <!-- Display history table -->
                <?php if (!empty($_SESSION['history'])): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Latitude</th>
                                <th>Longitude</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Date and Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($_SESSION['history'] as $index => $marker): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($marker['lat']); ?></td>
                                    <td><?php echo htmlspecialchars($marker['lng']); ?></td>
                                    <td><?php echo htmlspecialchars($marker['name']); ?></td>
                                    <td><?php echo htmlspecialchars($marker['address']); ?></td>
                                    <td><?php echo htmlspecialchars(date('Y-m-d H:i:s', strtotime($marker['timestamp']))); ?></td>
                                    <td>
                                        <form method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                            <input type="hidden" name="delete" value="<?php echo $marker['id']; ?>">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No markers in history.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>